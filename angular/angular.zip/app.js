angular.module("FootballApp", ['ngRoute', 'angularUtils.directives.dirPagination']).config(config).directive('backImg', backImg);

function backImg(){
    return function(scope, element, attrs){
        var url = attrs.backImg;
        element.css({
            'background-image': 'url(' + url +')',
             'height': '100%',
             'background-attachment': 'fixed',
             'background-position': 'center',
             'background-repeat': 'no-repeat',
             'background-size': 'cover'
        });
    };
}

function config($routeProvider, $locationProvider){
    $locationProvider.html5Mode(true).hashPrefix('!');
    $routeProvider.when("/", {
        controller: 'AllController',
        controllerAs: 'vm',
        templateUrl: 'angular/templates/all.html'
    });

}

function getCount(parent, getChildrensChildren){
    var relevantChildren = 0;
    var children = parent.childNodes.length;
    for(var i=0; i < children; i++){
        if(parent.childNodes[i].nodeType != 3){
            if(getChildrensChildren)
                relevantChildren += getCount(parent.childNodes[i],true);
            relevantChildren++;
        }
    }
    return relevantChildren;
}