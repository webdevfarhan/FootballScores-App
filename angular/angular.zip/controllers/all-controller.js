angular.module("FootballApp").controller("AllController", AllController);

function AllController($http){
    var vm = this;
    $http.get("https://raw.githubusercontent.com/openfootball/football.json/master/2015-16/en.1.json").then(function(response){
        vm.response = response.data;
        vm.rounds = vm.response.rounds;
        $http.get("https://raw.githubusercontent.com/openfootball/football.json/master/2016-17/en.1.json").then(function(response1){
            vm.response1 = response1.data;
            vm.rounds1 = vm.response1.rounds;
        });
    });
    vm.countElem = function() {
        var tables = document.querySelectorAll('table').length;
        console.log("Total Tables" + tables);
        return tables;
      }
}